///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package com.mycompany.spring.boot.app;
//
//import java.util.List;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
///**
// *
// * @author bas200181
// */
//@RestController
//public class UserController {
//
////    @Autowired
//    UserServ us;
////    @Autowired
//    SecurityFilter1 sf;
//    
////    @RequestMapping("/addusr")
//    public int add() {
////        User u = new User("kannan", sf.pwdEncoder().encode("kanannan"));
//        User u = new User("kannan", "kanannan");
//        return us.addUserr(u);
//    }
//    
//
//    
//    
//}
