/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.khatabook.idao;

import com.khatabook.model.Payment;

/**
 *
 * @author bas200181
 */
public interface PaymentDao {
  public int pay(Payment p);
  
}
