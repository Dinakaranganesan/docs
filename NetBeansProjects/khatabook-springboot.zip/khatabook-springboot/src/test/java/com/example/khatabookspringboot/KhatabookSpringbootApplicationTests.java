package com.example.khatabookspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhatabookSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
