package com.example.khatabookspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhatabookSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(KhatabookSpringbootApplication.class, args);
	}

}
